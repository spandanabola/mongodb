const mongoose = require('mongoose');
var schedule = require('./newfetch');
module.exports = {
    getProjectDetails: (req, res) => {
        ses = req.session;
        var info = {};
        var id = 0;
        var count = 0, success = 0, failed = 0, executionTime = 0;
        //ses.email = "spandanabola@gmail.com";
       var userId = req.headers['userid'];

       console.log(req.headers);
        console.log("*****************************"+userId);
        if (userId=='123456') {
            var testSuites = require('../models/testSuites.js');
            var TestSuite = mongoose.model('testsuites', testSuites)
            var getClientApps = require('../models/client.js');
            var GetClientApp = mongoose.model('clients', getClientApps);
            console.log("inside client apps");
           // console.log(req.body);
            GetClientApp.findOne({ 'title': req.body.title, 'appVer': req.body.appVer }, (err, docs) => {
                if (err) {
                    info = {
                        stat: false,
                        msg: err
                    }
                    res.send(info);
                    res.end();
                    //console.log(docs);

                } else {
                    console.log(docs);
                    id = docs._id;
                   // console.log(docs._id);
                    TestSuite.find({ 'appId': id }, (err, doc) => {
                        if (err) {
                            info = {
                                stat: false,
                                msg: err
                            }
                            res.send(info);
                            res.end();
                        } else {
                            console.log("Doc Length ", doc.length);
                            var total=0;
                             for (var i = 0; i < doc.length; i++) {
                                for (var j = 0; j < doc[i].test_suites.length; j++) {
                                    total=total+1;
                                }
                             }

                            for (var i = 0; i < doc.length; i++) {
                                for (var j = 0; j < doc[i].test_suites.length; j++) {
                                    //executionTime= executionTime+docs[i].test_suites[j].executionTime;


                                    schedule.runTestSuites(doc[i].test_suites[j], function (response) {
                                        //console.log(response)
                                        count = count + 1;
                                        executionTime = executionTime + response.time;
                                        if (response.stat == true) {
                                            console.log("inside success count")
                                            success = success + 1;
                                        }
                                        else {
                                            console.log("inside fail count")
                                            failed = failed + 1;
                                        }
                                       
                                        if (count==total) {
                                            console.log("count:=" + count)
                                            info = {
                                                TotalTestCases: count,
                                                SuccessTestCases: success,
                                                failed: failed,
                                                ExecutionTime: executionTime
                                            }
                                            res.send(info);
                                            res.end();
                                        }

                                    });

                                }
                            }


                        };

                    });

                };
            });
        }
        else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.status(401);
            res.end();

        }
    }
}
