const mongoose=require('mongoose');
module.exports={
      getProjects: (req, res) => {
        ses = req.session;
        var info = {};
        var titles=[];
        var versions=[];
        var userId = req.headers['userid'];
        //ses.email = "spandanabola@gmail.com";
        if (userId=='123456') {

            var getClientApps = require('../models/client.js');
            var GetClientApp = mongoose.model('clients', getClientApps);
            console.log("inside client apps");
            GetClientApp.find({}, (err, docs) => {
                if (err) {
                     info = {
                        stat: false,
                        msg: err
                    }

                    //console.log(docs);
                    
                } else {

                    for(var i=0;i<docs.length;i++)
                        {
                            
                             titles.push(docs[i].title); 
                             versions.push(docs[i].appVer); 
                           // title[]=docs[i].title;
                           // version[]=docs[i].appVer;
                        }
                   info = {
                         stat: true,
                        // doc: docs,
                         title:titles,
                         version:versions
                    }

                };
                res.send(info);
                res.end();

            });

        } else {
            info = {
                stat: false,
                msg: "please login to create app "
            }
            res.status(401);
            res.end();

        }


    }
}