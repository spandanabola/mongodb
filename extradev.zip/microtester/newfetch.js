const mongoose = require('mongoose');
const httpsProxyAgent = require('https-proxy-agent');
var fetch = require('node-fetch');
var assert = require('assert');
var isJson = require('is-valid-json');
var agents = null;
module.exports = {
    runTestSuites: function (data,callback) {
        //ses = req.session;
        var url = data.url;
        console.log(data);
        if (url.includes("dpod.gerenewables.com") || url.includes("fssfed.stage.ge.com") || url.includes("amazonaws.com") || url.includes("fssfed.ge.com") || url.includes("predix.io")) {
            console.log("################################################## Inside Predix Domain ###########################################");
            agents = new httpsProxyAgent("http://cis-india-pitc-bangalorez.proxy.corporate.ge.com:80");
            //agents = null;
        } else {
            console.log("################################################## Outside Predix Domain ###########################################");
            agents = null;
        }

        if (JSON.stringify(data.header) != "{}") {
            console.log("inside JSON");
           data.header = JSON.parse(data.header);
        } else {
            data.header = data.header;
        }


        var options = {
            // These properties are part of the Fetch Standard
            method: data.selectedReqType,
            headers: data.header,
            body: data.body,
            // request body. can be null, a string, a Buffer, a Blob, or a Node.js Readable stream
            redirect: 'follow', // set to `manual` to extract redirect headers, `error` to reject redirect
            //cert: fs.readFileSync('../GE_ROOT.cer'),
            // // // The following properties are node-fetch extensions
            follow: 20,         // maximum redirect count. 0 to not follow redirect
            timeout: 0,         // req/res timeout in ms, it resets on redirect. 0 to disable (OS limit applies)
            compress: true,     // support gzip/deflate content encoding. false to disable
            size: 0,            // maximum response body size in bytes. 0 to disable
            agent: agents         // http(s).Agent instance, allows custom proxy, certificate etc.
        }
        //console.log(fs.readFileSync('../GE_ROOT.cer'));
        /*process.env.NODE_TLS_REJECT_UNAUTHORIZED = "0";
        { key: "age", value: "", notnullCheck: true, type: "number" }
*/
        var keyExist = false;
        var containMsg = "";
        var responseBody = "";
        console.log("url " + data.url);
        var startTime = new Date().getTime();
        var endTime = "";
        var statusCode="";
        var statusText="";
        fetch(data.url, options)
            .then(function successCallback(response) {
                console.log("inside success hitapi");
                endTime = new Date().getTime();
                console.log(response.status);
                console.log(endTime - startTime);
                statusCode=response.status;
                statusText=response.statusText;
                

                // if (req.body.unitTest.configuration.responseType !== "") {
                //     console.log("inside response check");
                //     if (req.body.unitTest.configuration.responseType === 'Plain/text') {
                //         console.log("inside string");
                //         return response.text();
                //     }
                //     else if (req.body.unitTest.configuration.responseType === 'application/json') {
                //         console.log("inside json");
                //         return response.json();
                //     }
                // } else {
                return response.text();
                // }
            }).then(function (body) {
               // console.log(body);
               // console.log(typeof (body));
                responseBody = body;
                if (data.unitTest.configuration.statusCode === "") {
                    data.unitTest.configuration.statusCode = null;
                } else {

                };
                if (data.unitTest.configuration.statusCode != null) {
                    console.log("inside status check");
                    assert.deepEqual(statusCode, data.unitTest.configuration.statusCode, "response status is not matched with expected");
                }
                else if (data.unitTest.configuration.statusCode === null) {
                    console.log("inside status check");
                    assert.deepEqual(statusCode, 200, statusText);
                }else{

                };
                console.log("$$$$$$$$$$$");
                if (data.unitTest.configuration.responseType === "") {
                    data.unitTest.configuration.responseType = null;
                } else {

                };
                if (data.unitTest.configuration.responseType != null) {
                    if (data.unitTest.configuration.responseType === 'Plain/text') {
                        console.log("inside string");
                        if (isJson(body)) {
                            throw Error("reponse data is not string");
                        } else {
                            assert.deepStrictEqual(typeof (body), typeof ("string"), "type of response data is not matched");
                            if ((body + "") == "" || body == null) {
                                throw Error("reponse data is empty or null");
                            } else {
                                if (data.unitTest.configuration.textData.type != "") {
                                    if (data.unitTest.configuration.textData.type === "Exact Match") {
                                        assert.deepEqual(body,data.unitTest.configuration.textData.value, "response data is not matched");
                                    }
                                    else if (data.unitTest.configuration.textData.type === "Contains") {

                                        if (data.unitTest.configuration.textData.value != "") {
                                            if ((body + "").includes(data.unitTest.configuration.textData.value)) {
                                                console.log("matched");
                                            } else {
                                                throw Error("reponse data is not contains the specified value");
                                            }
                                        }



                                    }
                                }
                            }

                        }


                        info = {
                            stat: true,
                            //body: body,
                            time: endTime - startTime
                        }
                        // res.send(info);
                        // res.end();
                        //return info;
                        callback(info);
                    }
                    else if (data.unitTest.configuration.responseType === "Application/json") {
                        console.log("inside json");
                        if (isJson(body)) {
                            console.log("valid json");
                            console.log("**************************");
                            console.log(data.unitTest.configuration.jsonData);
                            body = JSON.parse(body);
                            if (body.constructor === {}.constructor) {
                                for (var i = 0; i < data.unitTest.configuration.jsonData.length; i++) {
                                    console.log("inside for loop " + data.unitTest.configuration.jsonData.length);
                                    keyExist = false;
                                    for (var key in body) {
                                        console.log(key);
                                        if (key == data.unitTest.configuration.jsonData[i].key) {
                                            keyExist = true
                                        }
                                    }
                                    if (keyExist == false) {
                                        throw Error(data.unitTest.configuration.jsonData[i].key + " is not present in reponse data");

                                    } else {

                                        console.log("key present " + data.unitTest.configuration.jsonData[i].key);
                                        var value = data.unitTest.configuration.jsonData[i].value.toLowerCase();
                                        if (data.unitTest.configuration.jsonData[i].type !== "") {
                                            if (data.unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                if (value === 'false') {
                                                    assert.deepEqual(body[data.unitTest.configuration.jsonData[i].key], false, "response data is not matched");
                                                } else if (value === 'true') {
                                                    assert.deepEqual(body[data.unitTest.configuration.jsonData[i].key], true, "response data is not matched");
                                                } else if (value === 'null') {
                                                    assert.deepEqual(body[data.unitTest.configuration.jsonData[i].key], null, "response data is not matched");
                                                } else {
                                                    assert.deepEqual(body[data.unitTest.configuration.jsonData[i].key], data.unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                }

                                            }
                                            else if (data.unitTest.configuration.jsonData[i].type === "Contains") {
                                                if (body[data.unitTest.configuration.jsonData[i].key] == null || body[data.unitTest.configuration.jsonData[i].key] == "") {
                                                    throw Error(data.unitTest.configuration.jsonData[i].key + "key value is not present");
                                                } else {
                                                    if (data.unitTest.configuration.jsonData[i].value != "") {
                                                        if ((body[data.unitTest.configuration.jsonData[i].key] + "").includes(data.unitTest.configuration.jsonData[i].value)) {
                                                            console.log("matched");
                                                            //containMsg = ""
                                                        } else {
                                                            containMsg += "*: " + data.unitTest.configuration.jsonData[i].key + " key is present but " + data.unitTest.configuration.jsonData[i].value + "is not present in value"
                                                        }
                                                    }

                                                }

                                            }

                                        }
                                    }
                                }

                            } else if (body.constructor === [].constructor) {
                                for (var j = 0; j < body.length; j++) {
                                    for (var i = 0; i < data.unitTest.configuration.jsonData.length; i++) {
                                        console.log("inside for loop " + data.unitTest.configuration.jsonData.length);
                                        keyExist = false;
                                        for (var key in body[j]) {
                                            console.log(key);
                                            if (key == data.unitTest.configuration.jsonData[i].key) {
                                                keyExist = true
                                            }
                                        }
                                        if (keyExist == false) {
                                            throw Error(data.unitTest.configuration.jsonData[i].key + " key is not present in reponse data");

                                        } else {
                                            console.log("key present " + data.unitTest.configuration.jsonData[i].key);
                                            console.log(data.unitTest.configuration.jsonData[i].value.toLowerCase());
                                            var value = data.unitTest.configuration.jsonData[i].value.toLowerCase()

                                            if (data.unitTest.configuration.jsonData[i].type != "") {
                                                if (data.unitTest.configuration.jsonData[i].type === "Exact Match") {
                                                    if (value === 'false') {
                                                        assert.deepEqual(body[j][data.unitTest.configuration.jsonData[i].key], false, "response data is not matched");
                                                    } else if (value === 'true') {
                                                        assert.deepEqual(body[j][data.unitTest.configuration.jsonData[i].key], true, "response data is not matched");
                                                    } else if (value === 'null') {
                                                        assert.deepEqual(body[j][data.unitTest.configuration.jsonData[i].key], null, "response data is not matched");
                                                    } else {
                                                        assert.deepEqual(body[j][data.unitTest.configuration.jsonData[i].key], data.unitTest.configuration.jsonData[i].value, "response data is not matched");
                                                    }

                                                }
                                                else if (data.unitTest.configuration.jsonData[i].type === "Contains") {
                                                    console.log("contains");
                                                    console.log(body[j][data.unitTest.configuration.jsonData[i].key]);
                                                    console.log(data.unitTest.configuration.jsonData[i].value);
                                                    if (body[j][data.unitTest.configuration.jsonData[i].key] == null || body[j][data.unitTest.configuration.jsonData[i].key] == "") {
                                                        throw Error(data.unitTest.configuration.jsonData[i].key + "key value is not present");
                                                    } else {
                                                        if (data.unitTest.configuration.jsonData[i].value != "") {
                                                            if ((body[j][data.unitTest.configuration.jsonData[i].key] + "").includes(data.unitTest.configuration.jsonData[i].value)) {
                                                                console.log("matched");
                                                                //containMsg = ""
                                                            } else {
                                                                containMsg += "*: " +data.unitTest.configuration.jsonData[i].key + " key is present but " + data.unitTest.configuration.jsonData[i].value + "is not present in value"
                                                            }
                                                        }

                                                    }

                                                }

                                            }


                                        }
                                    }
                                }
                            }

                            info = {
                                stat: true,
                                //body: JSON.stringify(body),
                                time: endTime - startTime,
                               // msg: containMsg
                            }
                            // res.send(info);
                            // res.end();
                            //return info;
                            callback(info);
                        } else {
                            throw Error("reponse data is not valid json");
                        }
                    } else {

                    }

                } else {
                    console.log("response type is not given");
                    info = {
                        stat: true,
                        //body: responseBody,
                        time: endTime - startTime
                    }
                    // res.send(info);
                    // res.end();
                   // return info;
                   callback(info);
                }

            })
            .catch(function errorCallback(err) {

                console.log("inside failure hitapi");
                if (endTime === "") {
                    endTime = new Date().getTime();
                }
                console.log(err);
                info = {
                    stat: false,
                    msg: err.message,
                    time: endTime - startTime
                }
                // res.send(info);
                // res.end();
                //return info;
                //next(info);
                callback(info);
            });
    }
}